<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';

header('Content-Type: application/json');

// Check if the user is logged in and has the correct permissions
check_login();
check_permission('manager');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customer_id = intval($_POST['customer_id']);
    $bird_id = intval($_POST['bird_id']);
    $quantity = intval($_POST['quantity']);
    $total_price = floatval($_POST['total_price']);

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Check if there are enough birds available
        $check_quantity_sql = "SELECT count FROM birds WHERE id = ?";
        $check_stmt = $conn->prepare($check_quantity_sql);
        $check_stmt->bind_param("i", $bird_id);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        $bird_data = $result->fetch_assoc();

        if ($bird_data['count'] < $quantity) {
            throw new Exception("Not enough birds available for sale");
        }

        // Insert the sale record into the sales table
        $insert_sql = "INSERT INTO sales (customer_id, bird_id, quantity, total_price, sale_date) VALUES (?, ?, ?, ?, NOW())";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("iiid", $customer_id, $bird_id, $quantity, $total_price);

        if (!$insert_stmt->execute()) {
            throw new Exception("Failed to record sale");
        }

        // Update the bird count
        $update_sql = "UPDATE birds SET count = count - ? WHERE id = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("ii", $quantity, $bird_id);

        if (!$update_stmt->execute()) {
            throw new Exception("Failed to update bird count");
        }

        // Commit the transaction
        $conn->commit();

        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        // An error occurred, rollback the transaction
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
