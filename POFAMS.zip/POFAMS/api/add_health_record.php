<?php
// Turn off error reporting to prevent output of errors
error_reporting(0);
ini_set('display_errors', 0);

// Start output buffering to capture any unexpected output
ob_start();

session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';

header('Content-Type: application/json');

function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . "add_health_record.php error: " . $message . "\n", 3, '../logs/error.log');
}

try {
    check_login();
    check_permission('employee');

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $bird_id = filter_input(INPUT_POST, 'bird_id', FILTER_VALIDATE_INT);
        $record_type = filter_input(INPUT_POST, 'record_type', FILTER_SANITIZE_STRING);
        $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);

        if (!$bird_id || !$record_type || !$description) {
            throw new Exception('Invalid input data: bird_id=' . var_export($bird_id, true) . ', record_type=' . var_export($record_type, true) . ', description=' . var_export($description, true));
        }

        $sql = "INSERT INTO health_records (bird_id, record_type, description) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            throw new Exception('Failed to prepare statement: ' . $conn->error);
        }

        $stmt->bind_param("iss", $bird_id, $record_type, $description);
        if (!$stmt->execute()) {
            throw new Exception('Failed to execute statement: ' . $stmt->error);
        }

        $response = ['success' => true, 'message' => 'Health record added successfully'];
    } else {
        throw new Exception('Invalid request method: ' . $_SERVER['REQUEST_METHOD']);
    }
} catch (Exception $e) {
    logError($e->getMessage());
    $response = ['success' => false, 'error' => $e->getMessage()];
}

// Capture any unexpected output
$output = ob_get_clean();
if (!empty($output)) {
    logError("Unexpected output: " . $output);
    $response['unexpectedOutput'] = $output;
}

echo json_encode($response);
?>