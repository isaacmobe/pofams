<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';
check_login();
check_permission('manager');

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $age_group = $_POST['age_group'];
    $count = intval($_POST['count']);

    // Validate age_group
    $valid_age_groups = ['0-11 days', '12-25 days', '26+ days'];
    if (!in_array($age_group, $valid_age_groups)) {
        echo json_encode(['success' => false, 'error' => 'Invalid age group']);
        exit;
    }

    // Validate count
    if ($count < 0) {
        echo json_encode(['success' => false, 'error' => 'Count cannot be negative']);
        exit;
    }

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Check if the age group already exists
        $check_sql = "SELECT id FROM birds WHERE age_group = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $age_group);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            throw new Exception("Age group already exists");
        }

        // Insert the new bird group
        $sql = "INSERT INTO birds (age_group, count) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $age_group, $count);

        if (!$stmt->execute()) {
            throw new Exception("Failed to add new bird group: " . $stmt->error);
        }

        $new_bird_id = $conn->insert_id;

        // Log the activity
        $user_id = $_SESSION['user_id'];
        $activity = "Added new bird group: $age_group with initial count $count";
        $log_sql = "INSERT INTO activities (user_id, activity) VALUES (?, ?)";
        $log_stmt = $conn->prepare($log_sql);
        $log_stmt->bind_param("is", $user_id, $activity);

        if (!$log_stmt->execute()) {
            throw new Exception("Failed to log activity: " . $log_stmt->error);
        }

        // Commit the transaction
        $conn->commit();
        echo json_encode(['success' => true, 'id' => $new_bird_id]);
    } catch (Exception $e) {
        // An error occurred, rollback the transaction
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}