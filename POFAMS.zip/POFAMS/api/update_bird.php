<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';
check_login();
check_permission('manager');

header('Content-Type: application/json');

function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . "Update Bird Error: " . $message . "\n", 3, "../logs/error.log");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        logError("JSON decode error: " . json_last_error_msg());
        echo json_encode(['success' => false, 'error' => 'Invalid JSON input']);
        exit;
    }

    if (!isset($data['id']) || !isset($data['count'])) {
        logError("Missing required fields in input");
        echo json_encode(['success' => false, 'error' => 'Missing required fields']);
        exit;
    }

    $id = intval($data['id']);
    $count = intval($data['count']);

    // Validate input
    if ($count < 0) {
        logError("Invalid count: $count");
        echo json_encode(['success' => false, 'error' => 'Count cannot be negative']);
        exit;
    }

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Update the bird count
        $sql = "UPDATE birds SET count = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $count, $id);

        if (!$stmt->execute()) {
            throw new Exception("Failed to update bird count: " . $stmt->error);
        }

        if ($stmt->affected_rows == 0) {
            throw new Exception("No bird found with the given ID: $id");
        }

        // Log the update in the activity table
        $user_id = $_SESSION['user_id'];
        $activity = "Updated bird count for ID $id to $count";
        $log_sql = "INSERT INTO activities (user_id, activity) VALUES (?, ?)";
        $log_stmt = $conn->prepare($log_sql);
        $log_stmt->bind_param("is", $user_id, $activity);

        if (!$log_stmt->execute()) {
            throw new Exception("Failed to log activity: " . $log_stmt->error);
        }

        // Commit the transaction
        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        // An error occurred, rollback the transaction
        $conn->rollback();
        logError($e->getMessage());
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    logError("Invalid request method: " . $_SERVER['REQUEST_METHOD']);
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}