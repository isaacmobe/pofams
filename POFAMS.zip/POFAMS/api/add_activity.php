<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';
check_login();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $activity = $_POST['activity'];
    $user_id = $_SESSION['user_id'];

    // Start a transaction
    $conn->begin_transaction();

    try {
        // Insert the new activity
        $sql = "INSERT INTO activities (user_id, activity) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $user_id, $activity);

        if (!$stmt->execute()) {
            throw new Exception("Failed to add new activity");
        }

        $new_activity_id = $conn->insert_id;

        // Fetch the username for the response
        $user_sql = "SELECT username FROM users WHERE id = ?";
        $user_stmt = $conn->prepare($user_sql);
        $user_stmt->bind_param("i", $user_id);
        $user_stmt->execute();
        $user_result = $user_stmt->get_result();
        $user_row = $user_result->fetch_assoc();
        $username = $user_row['username'];

        // If we've made it this far, commit the transaction
        $conn->commit();
        
        echo json_encode([
            'success' => true, 
            'id' => $new_activity_id,
            'username' => $username,
            'activity' => $activity,
            'created_at' => date('Y-m-d H:i:s')
        ]);
    } catch (Exception $e) {
        // An error occurred, rollback the transaction
        $conn->rollback();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?>