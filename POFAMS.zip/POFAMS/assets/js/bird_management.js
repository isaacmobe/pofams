// Update existing bird counts
document.querySelectorAll('.update-bird-form').forEach(form => {
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const birdId = this.querySelector('[name="bird_id"]').value;
        const count = this.querySelector('[name="count"]').value;

        fetch('/api/update_bird.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                id: birdId,
                count: count
            }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Bird count updated successfully');
                document.getElementById(`count-${birdId}`).textContent = count;
            } else {
                alert('Failed to update bird count: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while updating bird count');
        });
    });
});

// Add new bird group
document.getElementById('add-bird-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);

    fetch('/api/add_bird.php', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('New bird group added successfully');
            location.reload(); // Refresh the page to show the new group
        } else {
            alert('Failed to add new bird group: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while adding new bird group');
    });
});