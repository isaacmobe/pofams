<?php
function check_login() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit();
    }
}

function get_user_role($user_id) {
    global $conn;
    $sql = "SELECT role FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    return $user['role'];
}

function check_permission($required_role) {
    $user_role = get_user_role($_SESSION['user_id']);
    if ($user_role !== $required_role) {
        header("Location: dashboard.php");
        exit();
    }
}


/**
 * Get total sales within a given date range.
 *
 * @param mysqli $conn The database connection object.
 * @param string $start_date The start date in 'Y-m-d' format.
 * @param string $end_date The end date in 'Y-m-d' format.
 * @return float The total sales amount.
 */

function calculateTotalSales($conn, $start_date, $end_date) {
    $sql = "SELECT SUM(total_price) AS total_sales FROM sales WHERE sale_date BETWEEN ? AND ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['total_sales'] ?? 0.0; // Return 0.0 if no sales found
}

