<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="shortcut icon" href="../assets/images/chicken.png" type="image/x-icon">
    <title><?php echo SITE_NAME; ?></title>
</head>
<body>
   <nav class="dashnav">
        <ul>
            <li><a href="../pages/dashboard.php"><i class='bx bxs-dashboard'></i>Dashboard</a></li>
            <li><a href="../pages/inventory.php"><i class='bx bx-cube'></i>Inventory</a></li>
            <li><a href="../pages/activities.php"><i class='bx bx-calendar-event'></i>Activities</a></li>
            <li><a href="../pages/health.php"><i class='bx bx-heart'></i>Health</a></li>
            <li><a href="../pages/bird_inventory.php"><i class='bx bx-dna'></i>Bird Inventory</a></li>
            <li><a href="../pages/sales.php"><i class='bx bx-line-chart'></i>Sales</a></li>
            <li><a href="../pages/reports.php"><i class='bx bx-bar-chart-square'></i>Reports</a></li>
            <li><a href="../pages/market_prediction.php"><i class='bx bx-trending-up'></i>Market Prediction</a></li>
            <li><a href="../pages/logout.php"><i class='bx bx-log-out'></i>Logout</a></li>
        </ul>
    </nav> 
</body>
