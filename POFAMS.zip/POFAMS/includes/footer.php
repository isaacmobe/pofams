<footer>
        <a href="../index.php"><p>&copy; <?php echo date("Y"); ?> <?php echo SITE_NAME; ?></p></a>
    </footer>
    <script src="/assets/js/main.js"></script>
</body>
</html>