<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- LINK TO ICONS BY BOXICONS -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <!-- LINK TO CSS STYLES -->
    <link rel="stylesheet" href="./assets/css/styles.css">
    <!-- FAVICON -->
    <link rel="shortcut icon" href="./assets/images/chicken.png" type="image/x-icon">
    <title><?php echo SITE_NAME; ?></title>
</head>
<body>
    <header>
        <h1><?php echo SITE_NAME; ?></h1>
    </header>