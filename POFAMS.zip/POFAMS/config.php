<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'poultry_management');

define('SITE_NAME', 'POFAMS');
?>