<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';

check_login();
check_permission('manager');

include '../includes/navigation.php';

// Fetch the recent sales
$sql = "SELECT s.*, u.username, b.age_group FROM sales s 
        JOIN users u ON s.customer_id = u.id 
        JOIN birds b ON s.bird_id = b.id 
        ORDER BY s.sale_date DESC LIMIT 20";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="shortcut icon" href="../assets/images/chicken.png" type="image/x-icon">
    <title><?php echo SITE_NAME; ?> - Sales</title>
</head>
<body>

<div class="sales container">
    <div class="sales-container">
        <h2>Sales</h2>

        <form id="addSaleForm" class="form-container">
            <label for="customer_id">Customer:</label>
            <select id="customer_id" name="customer_id" required>
                <?php
                $customer_sql = "SELECT id, username FROM users WHERE role = 'customer'";
                $customer_result = $conn->query($customer_sql);
                while ($customer = $customer_result->fetch_assoc()) {
                    echo "<option value='" . $customer['id'] . "'>" . htmlspecialchars($customer['username']) . "</option>";
                }
                ?>
            </select>

            <label for="bird_id">Bird Group:</label>
            <select id="bird_id" name="bird_id" required>
                <?php
                $bird_sql = "SELECT * FROM birds";
                $bird_result = $conn->query($bird_sql);
                while ($bird = $bird_result->fetch_assoc()) {
                    echo "<option value='" . $bird['id'] . "'>" . htmlspecialchars($bird['age_group']) . " (Available: " . htmlspecialchars($bird['count']) . ")</option>";
                }
                ?>
            </select>

            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" required min="1">

            <label for="total_price">Total Price:</label>
            <input type="number" id="total_price" name="total_price" required min="0" step="0.01">

            <button type="submit" class="regbtn">Record Sale</button>
        </form>

        <h3>Recent Sales</h3>
        <table class="inventory-table">
            <tr>
                <th>Customer</th>
                <th>Bird Group</th>
                <th>Quantity</th>
                <th>Total Price</th>
                <th>Sale Date</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['username']); ?></td>
                <td><?php echo htmlspecialchars($row['age_group']); ?></td>
                <td><?php echo $row['quantity']; ?></td>
                <td><?php echo $row['total_price']; ?></td>
                <td><?php echo $row['sale_date']; ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>

<script>
document.getElementById('addSaleForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);

    fetch('../api/add_sale.php', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Sale recorded successfully');
            location.reload();
        } else {
            alert('Failed to record sale: ' + (data.error || 'Unknown error'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while recording the sale');
    });
});
</script>

</body>
</html>
