<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';
check_login();
check_permission('employee');

include '../includes/navigation.php';

$sql = "SELECT h.*, b.age_group FROM health_records h JOIN birds b ON h.bird_id = b.id ORDER BY h.created_at DESC LIMIT 20";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="shortcut icon" href="../assets/images/chicken.png" type="image/x-icon">
    <title><?php echo SITE_NAME; ?> - Health record</title>
</head>
<body>

<div class="health container">
    <div class="health-container">
        <h2>Health Records</h2>
 
        <form id="addHealthRecordForm" class="form-container">
            <label for="bird_id">Bird Group:</label>
            <select id="bird_id" name="bird_id" required>
                <?php
                $bird_sql = "SELECT * FROM birds";
                $bird_result = $conn->query($bird_sql);
                while ($bird = $bird_result->fetch_assoc()) {
                    echo "<option value='" . $bird['id'] . "'>" . $bird['age_group'] . "</option>";
                }
                ?>
            </select>
        
            <label for="record_type">Record Type:</label>
            <select id="record_type" name="record_type" required>
                <option value="medication">Medication</option>
                <option value="vaccination">Vaccination</option>
                <option value="check-up">Check-up</option>
            </select>
        
            <label for="description">Description:</label>
            <textarea id="description" name="description" class="textarea" required></textarea>
        
            <button type="submit" class="regbtn">Add Health Record</button>
        </form>
 
        <h3>Recent Health Records</h3>
        <table class="inventory-table">
            <tr>
                <th>Bird Group</th>
                <th>Record Type</th>
                <th>Description</th>
                <th>Date</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['age_group']); ?></td>
                <td><?php echo htmlspecialchars($row['record_type']); ?></td>
                <td><?php echo htmlspecialchars($row['description']); ?></td>
                <td><?php echo $row['created_at']; ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>

<script>
document.getElementById('addHealthRecordForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const formData = new FormData(this);

    console.log('Sending form data:');
    for (let [key, value] of formData.entries()) {
        console.log(key, value);
    }

    fetch('../api/add_health_record.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(text => {
        console.log('Raw server response:', text);
        try {
            return JSON.parse(text);
        } catch (error) {
            throw new Error('Failed to parse server response: ' + error.message);
        }
    })
    .then(data => {
        console.log('Parsed server response:', data);
        if (data.success) {
            alert('Health record added successfully');
            location.reload();
        } else {
            let errorMessage = data.error || 'Unknown error';
            if (data.unexpectedOutput) {
                errorMessage += '\nUnexpected output: ' + data.unexpectedOutput;
            }
            alert('Failed to add health record: ' + errorMessage);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while adding the health record: ' + error.message);
    });
});
</script>
</body>
</html>