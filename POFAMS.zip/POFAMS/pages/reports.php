<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';
check_login();
check_permission('manager');

include '../includes/header.php';
include '../includes/navigation.php';

// Function to get total sales for a given period
function getTotalSales($conn, $start_date, $end_date) {
    $sql = "SELECT SUM(total_price) as total FROM sales WHERE sale_date BETWEEN ? AND ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $start_date, $end_date);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc()['total'] ?? 0;
}

// Function to get bird count by age group
function getBirdCount($conn) {
    $sql = "SELECT age_group, SUM(count) as total FROM birds GROUP BY age_group";
    $result = $conn->query($sql);
    $bird_count = [];
    while ($row = $result->fetch_assoc()) {
        $bird_count[$row['age_group']] = $row['total'];
    }
    return $bird_count;
}

$current_month_sales = getTotalSales($conn, date('Y-m-01'), date('Y-m-t'));
$previous_month_sales = getTotalSales($conn, date('Y-m-01', strtotime('-1 month')), date('Y-m-t', strtotime('-1 month')));
$bird_count = getBirdCount($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="shortcut icon" href="../assets/images/chicken.png" type="image/x-icon">
    <title><?php echo SITE_NAME; ?> - Reports</title>
</head>
<body>

<div class="reports container">
    <div class="reports-container">
        <h2>Reports</h2>

        <h3>Sales Summary</h3>
        <p>Current Month Sales: $<?php echo number_format($current_month_sales, 2); ?></p>
        <p>Previous Month Sales: $<?php echo number_format($previous_month_sales, 2); ?></p>

        <h3>Bird Inventory</h3>
        <ul>
            <?php foreach ($bird_count as $age_group => $count): ?>
            <li><?php echo htmlspecialchars($age_group); ?>: <?php echo $count; ?></li>
            <?php endforeach; ?>
        </ul>

        <h3>Sales Chart</h3>
        <canvas id="salesChart" width="400" height="200"></canvas>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
var ctx = document.getElementById('salesChart').getContext('2d');
var salesChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Previous Month', 'Current Month'],
        datasets: [{
            label: 'Sales',
            data: [<?php echo $previous_month_sales; ?>, <?php echo $current_month_sales; ?>],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});
</script>

</body>
</html>