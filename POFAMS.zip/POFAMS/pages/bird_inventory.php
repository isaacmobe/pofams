<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';
check_login();
check_permission('manager');

include '../includes/navigation.php'; 

$sql = "SELECT * FROM birds ORDER BY FIELD(age_group, '0-11 days', '12-25 days', '26+ days')";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="shortcut icon" href="../assets/images/chicken.png" type="image/x-icon">
    <title><?php echo SITE_NAME; ?> - Bird Inventory</title>
</head>
<body>

<div class="bird-inventory container">
    <div class="inventory-container">
        <h2>Bird Inventory Management</h2>

        <table class="inventory-table">
            <tr>
                <th>Age Group</th>
                <th>Count</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['age_group']); ?></td>
                <td id="count-<?php echo $row['id']; ?>"><?php echo $row['count']; ?></td>
                <td>
                    <form class="update-bird-form">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <input type="number" name="count" value="<?php echo $row['count']; ?>" required min="0">
                        <button type="submit" class="regbtn">Update</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>

        <h3>Add New Bird Group</h3>
        <form id="add-bird-form" class="form-container">
            <label for="age_group">Age Group:</label>
            <select id="age_group" name="age_group" required>
                <option value="0-11 days">0-11 days</option>
                <option value="12-25 days">12-25 days</option>
                <option value="26+ days">26+ days</option>
            </select>
            <label for="count">Initial Count:</label>
            <input type="number" id="count" name="count" required min="0">
            <button type="submit" class="regbtn">Add Bird Group</button>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Handle update bird form submissions
        document.querySelectorAll('.update-bird-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                const formData = new FormData(this);
                const data = Object.fromEntries(formData.entries());

                fetch('../api/update_bird.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(data)
                })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        alert('Bird count updated successfully');
                        document.getElementById(`count-${data.id}`).textContent = data.count;
                    } else {
                        alert('Error: ' + result.error);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while updating the bird count');
                });
            });
        });

        // Handle add bird form submission
        document.getElementById('add-bird-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);

            fetch('../api/add_bird.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    alert('New bird group added successfully');
                    location.reload(); // Reload the page to show the new group
                } else {
                    alert('Error: ' + result.error);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while adding the new bird group');
            });
        });
    });
</script>
</body>
</html>