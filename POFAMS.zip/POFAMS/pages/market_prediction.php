<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';
check_login();
check_permission('manager');

include '../includes/header.php';
include '../includes/navigation.php';

// Simple market prediction based on previous month's sales
$previous_month_sales = calculateTotalSales($conn, date('Y-m-01', strtotime('-1 month')), date('Y-m-t', strtotime('-1 month')));
$prediction = $previous_month_sales * 1.1; // Predict 10% growth

// Get bird prices
$sql = "SELECT age_group, AVG(total_price / quantity) as avg_price FROM sales JOIN birds ON sales.bird_id = birds.id GROUP BY age_group";
$result = $conn->query($sql);
$bird_prices = [];
while ($row = $result->fetch_assoc()) {
    $bird_prices[$row['age_group']] = $row['avg_price'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="shortcut icon" href="../assets/images/chicken.png" type="image/x-icon">
    <title><?php echo SITE_NAME; ?> - Prediction</title>
</head>
<body>

<div class="market container">
    <div class="market-container">
        <h2>Market Prediction</h2>

        <h3>Sales Forecast</h3>
        <p>Based on last month's sales of $<?php echo number_format($previous_month_sales, 2); ?>, we predict this month's sales to be around $<?php echo number_format($prediction, 2); ?>.</p>

        <h3>Current Average Bird Prices</h3>
        <ul>
            <?php foreach ($bird_prices as $age_group => $price): ?>
            <li><?php echo htmlspecialchars($age_group); ?>: $<?php echo number_format($price, 2); ?> per bird</li>
            <?php endforeach; ?>
        </ul>

        <h3>Market Trends</h3>
        <p>Here are some factors that could affect the poultry market:</p>
        <ul>
            <li>Seasonal demand (e.g., higher demand during holidays)</li>
            <li>Feed prices</li>
            <li>Weather conditions</li>
            <li>Disease outbreaks</li>
            <li>Consumer preferences (e.g., organic vs. conventional)</li>
        </ul>

        <p>It's important to monitor these factors and adjust your strategy accordingly.</p>
    </div>
</div>
</body>
</html>