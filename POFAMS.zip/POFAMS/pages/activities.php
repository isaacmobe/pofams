<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';
check_login();

include '../includes/navigation.php';

$sql = "SELECT a.*, u.username FROM activities a JOIN users u ON a.user_id = u.id ORDER BY a.created_at DESC LIMIT 20";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="shortcut icon" href="../assets/images/chicken.png" type="image/x-icon">
    <title><?php echo SITE_NAME; ?> - Activities</title>
</head>
<body>
<div class="activities container">
    <div class="activities-container">
        <h2>Activities</h2>

        <form id="addActivityForm" class="form-container">
            <div class="fieldset">
                <label for="activity">New Activity:</label>
                <textarea id="activity" name="activity" placeholder="Notes on activities" required></textarea>
            </div>

            <button type="submit" class="regbtn">Log Activity</button>
        </form>

        <h3>Recent Activities</h3>
        <table id="activitiesTable">
            <tr>
                <th>User</th>
                <th>Activity</th>
                <th>Date</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['username']); ?></td>
                <td><?php echo htmlspecialchars($row['activity']); ?></td>
                <td><?php echo $row['created_at']; ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>

<script>
document.getElementById('addActivityForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('../api/add_activity.php', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Activity logged successfully');
            // Add the new activity to the table
            const table = document.getElementById('activitiesTable');
            const newRow = table.insertRow(1);
            newRow.innerHTML = `
                <td>${data.username}</td>
                <td>${data.activity}</td>
                <td>${data.created_at}</td>
            `;
            // Clear the form
            this.reset();
        } else {
            alert('Failed to log activity: ' + data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while logging the activity');
    });
});
</script>

</body>
</html>