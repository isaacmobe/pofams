<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';
check_login();

include '../includes/navigation.php';

$user_role = $_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="shortcut icon" href="../assets/images/chicken.png" type="image/x-icon">
    <title><?php echo SITE_NAME; ?> - Dashboard</title>
    <style>

    </style>
</head>
<body>
    <div class="dashboard container">
        <div class="dashboard-content">
            <h2>Dashboard</h2>
            <p>Welcome, <?php echo $_SESSION['username']; ?>!</p>

            <?php if ($user_role == 'manager' || $user_role == 'employee'): ?>
                <h3>Quick Stats</h3>
                <?php
                $sql = "SELECT SUM(count) as total_birds FROM birds";
                $result = $conn->query($sql);
                $total_birds = $result->fetch_assoc()['total_birds'];

                $sql = "SELECT COUNT(*) as total_activities FROM activities WHERE DATE(created_at) = CURDATE()";
                $result = $conn->query($sql);
                $total_activities = $result->fetch_assoc()['total_activities'];
                ?>
                <ul class="home-stat">
                    <li class="stat">Total Birds: <?php echo $total_birds; ?></li>
                    <li class="stat">Activities Today: <?php echo $total_activities; ?></li>
                </ul>
            <?php endif; ?>

            <?php if ($user_role == 'customer'): ?>
                <h3>Your Recent Orders</h3>
                <?php
                $user_id = $_SESSION['user_id'];
                $sql = "SELECT * FROM sales WHERE customer_id = ? ORDER BY sale_date DESC LIMIT 5";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $result = $stmt->get_result();
                ?>
                <table>
                    <tr>
                        <th>Order ID</th>
                        <th>Quantity</th>
                        <th>Total Price</th>
                        <th>Date</th>
                    </tr>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td><?php echo $row['total_price']; ?></td>
                        <td><?php echo $row['sale_date']; ?></td>
                    </tr>
                    <?php endwhile; ?>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>