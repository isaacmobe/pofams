<?php
session_start();
require_once '../config.php';
require_once '../functions.php';
require_once '../database/db_connection.php';
check_login();
check_permission('manager');

include '../includes/navigation.php';

$sql = "SELECT * FROM birds";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="shortcut icon" href="../assets/images/chicken.png" type="image/x-icon">
    <title><?php echo SITE_NAME; ?> - Inventory</title>
</head>
<body>

<div class="inventory container">
    <div class="inventory-container">
        <h2>Inventory</h2>
        
        <table class="inventory-table">
            <tr> 
                <th>ID</th>
                <th>Age Group</th>
                <th>Count</th>
                <th>Last Updated</th>
                <th>Action</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['id']); ?></td>
                <td><?php echo htmlspecialchars($row['age_group']); ?></td>
                <td><?php echo htmlspecialchars($row['count']); ?></td>
                <td><?php echo htmlspecialchars($row['updated_at']); ?></td>
                <td><button onclick="updateBird(<?php echo $row['id']; ?>)">Update</button></td>
            </tr>
            <?php endwhile; ?>
        </table>
        
        <h3>Add New Birds</h3>
        <form id="addBirdForm" class="form-container">
            <label for="age_group">Age Group:</label>
            <select id="age_group" name="age_group" required>
                <option value="0-11 days">0-11 days</option>
                <option value="12-25 days">12-25 days</option>
                <option value="26+ days">26+ days</option>
            </select>
            
            <label for="count">Count:</label>
            <input type="number" id="count" name="count" required>
            
            <button type="submit" class="regbtn">Add Birds</button>
        </form>
    </div>
</div>

<script>
function updateBird(id) {
    const count = prompt("Enter new count for bird group " + id);
    if (count !== null) {
        fetch('../api/update_bird.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id, count }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Bird count updated successfully');
                location.reload();
            } else {
                alert('Failed to update bird count: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while updating bird count');
        });
    }
}

document.getElementById('addBirdForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('../api/add_bird.php', {
        method: 'POST',
        body: formData,
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Birds added successfully');
            location.reload();
        } else {
            alert('Failed to add birds: ' + (data.error || 'Unknown error'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while adding birds');
    });
});
</script>

</body>
</html>