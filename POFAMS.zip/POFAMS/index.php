<?php
session_start();
require_once 'config.php';
require_once 'functions.php';

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: pages/dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- LINK TO ICONS BY BOXICONS -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <!-- LINK TO CSS STYLES -->
    <link rel="stylesheet" href="./assets/css/styles.css">
    <!-- FAVICON -->
    <link rel="shortcut icon" href="./assets/images/chicken.png" type="image/x-icon">
    <title><?php echo SITE_NAME; ?></title>
</head>
<body>
    <header class="header" id="header">
        <nav class="nav container padd-15">
            <a href="/" class="nav-logo">
                <img src="./assets/images/chicken.png" alt="logo" class="logo"><?php echo SITE_NAME; ?>
            </a>
            <ul class="nav-list">
                <li><a href="#about">About</a></li>
                <li><a href="#features">Features</a></li>
                <li><a href="./pages/register.php">Register</a></li>
                <li><a href="./pages/login.php">Login</a></li>
            </ul>
        </nav>
    </header>

    <main class="main-content">
        <!-- HOME SECTION -->
        <section class="home" id="home">
            <div class="container">
                <div class="home-content">
                    <div class="hero-img">
                        <img src="./assets/images/heroimage.jpg" alt="heroimg">
                    </div>
                    <div class="hero-right">
                        <p class="hero-text">
                            Welcome to <?php echo SITE_NAME; ?>, your online poultry 
                            management system, the future of online farm 
                            management is here.
                        </p>
                        <div class="ctabtns">
                            <a href="./pages/register.php" class="ctabtn1">Get Started</a>
                            <a href="#about" class="ctabtn2">Learn More</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ABOUT SECTION -->
        <section class="about" id="about">
            <div class="container">
                    <p class="about-title">
                        About - POFAMS
                    </p>
                <div class="about-container">
                    <div class="about-text">
                        <p class="textabout">
                            The Poultry Management System is a comprehensive 
                            solution designed to streamline the management of 
                            poultry farms. It offers a user-friendly interface 
                            for tracking various aspects of poultry farming, 
                            including bird inventory, feeding schedules, 
                            health monitoring, and performance metrics. 
                            With its intuitive design and robust functionality, 
                            this system helps farmers optimize their operations, 
                            improve efficiency, and make informed decisions to 
                            enhance productivity. Whether you are managing a 
                            small-scale farm or a large poultry operation, the 
                            Poultry Management System provides the tools 
                            you need to effectively manage your poultry and 
                            achieve your farming goals.
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <section class="features" id="features">
            <div class="container">
                    <p class="features-title">
                        POFAMS - Features
                    </p>
                <div class="features-container">
                    <div class="feature">
                        <img src="./assets/images/chickens.png" alt="" class="featureimg">
                        <p class="feature-title">
                            Health Tracking
                        </p>
                        <p class="description">
                            Monitor the health of your broilers with ease
                        </p>
                    </div>
                    <div class="feature">
                        <img src="./assets/images/diet.png" alt="" class="featureimg">
                        <p class="feature-title">
                            Feed Management
                        </p>
                        <p class="description">
                            Manage and schedule feed supplies efficiently
                        </p>
                    </div>
                    <div class="feature">
                        <img src="./assets/images/recruitment.png" alt="" class="featureimg">
                        <p class="feature-title">
                            Employee Management
                        </p>
                        <p class="description">
                            Track and Manage your workforce Effectively
                        </p>
                    </div>
                    <div class="feature">
                        <img src="./assets/images/order-fulfillment.png" alt="" class="featureimg">
                        <p class="feature-title">
                            Order Management
                        </p>
                        <p class="description">
                            Place and track orders seamlessly
                        </p>
                    </div>
                </div>
            </div>
        </section>
        
        <footer>
            <div class="footer-links">
                <a href="#about">About</a>
                <a href="./pages/register.php">Register</a>
            </div>
            <p>&copy; <?php echo date("Y") . ' ' . SITE_NAME; ?></p>
        </footer>

    </main>
</body>
</html>